from .fcn_mask_head import FCNMaskHead

__all__ = ['FCNMaskHead']
